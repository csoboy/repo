import re
import json
from urllib.parse import unquote
from urllib.parse import urlparse
import base64
import requests
from bs4 import BeautifulSoup
import resolveurl
from resolveurl import common
from resolveurl.resolver import ResolveUrl, ResolverError
from resolveurl.lib import helpers
import xbmc
from .. import common as cmn

class HdPlay(ResolveUrl):
    name = 'HDplay'
    domains = [ 'hdplay.se', 'adramas.se']
    # pattern = '(?://|\.)(hdplay\.se)/(.+)'
    pattern = '(?://|\.)(hdplay\.se|drive.adramas\.se)/(.+)'


    def __init__(self):
        self.net = common.Net()
        self.headers = {'User-Agent': common.RAND_UA, 'Referer':'https://drive.adramas.se/'}


    def get_media_url(self, host, media_id):
        url = self.get_url(host, media_id)
        
        if 'm3u8' in media_id :
            return url + helpers.append_headers(self.headers)
       
        response = requests.get(url, headers=self.headers)

        if response.status_code == 200:
            html = response.content.decode("utf-8")
            # capture everything, regardless of single or double quotes
            # match = re.search(r'var\s+video_url\s*=\s*"([^\\"]+)"', html)
            match = re.search(r'<div id=video_url style=display:none>(.+?)<\/div>', html)
            if match:
                video_url = 'http://' + host + match.group(1)
                #video_url = video_url.split('m3u8')[0]+'m3u8'
                return video_url + helpers.append_headers(self.headers)
            xbmc.log("html: %s" % html, xbmc.LOGERROR)


        raise ResolverError("Unable to resolve url in hdplay: %s" % response)

    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, 'http://%s/%s' % (host, media_id))

    @classmethod
    def _is_enabled(cls):
        return True
