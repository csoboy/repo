import httplib
import urllib,urllib2,re,sys
import cookielib,os,string,cookielib,StringIO,gzip
import os,time,base64,logging
from t0mm0.common.net import Net
import xml.dom.minidom
import xbmcaddon,xbmcplugin,xbmcgui
import base64
import xbmc
import datetime
import time
import json
import jsunpack 
import requests
import js2py

from bs4 import BeautifulSoup as BS
from urlparse import urljoin
from urlparse import urlparse

def BeautifulSoup(markup):
    return BS(markup, 'html5lib')

ADDON = xbmcaddon.Addon(id='plugin.video.azdrama')
if ADDON.getSetting('ga_visitor')=='':
    from random import randint
    ADDON.setSetting('ga_visitor',str(randint(0, 0x7fffffff)))
GA_PRIVACY = ADDON.getSetting('ga_privacy') == "true"
DISPLAY_MIRRORS = ADDON.getSetting('display_mirrors') == "true"

UASTR = "Mozilla/5.0 (Windows NT 6.1; WOW64; rv:13.0) Gecko/20100101 Firefox/13.0"
PATH = "AzDrama"  #<---- PLUGIN NAME MINUS THE "plugin.video"
UATRACK = "UA-76815405-1"
VERSION = "1.0.50" #<---- PLUGIN VERSION
domainlist = ["azdrama.net", "www.azdrama.info", "www1.azdrama.net", "icdrama.se", "azdrama.se", "dramas.se"]
domain = domainlist[int(ADDON.getSetting('domainurl'))]

if domain == "dramas.se" :
	domain = "icdrama.se"

# mode definitions
MODE_INDEX = 2
MODE_LOAD_VIDEOS = 3
MODE_SEARCH = 4
MODE_GA_EPISODES = 5
MODE_SERACH_RESULTS = 6
MODE_EPISODES = 7
MODE_PLAY = 8
MODE_GET_EPISODES = 9
MODE_EPISODES2 = 10
MODE_CHECKPARTS = 11

def __init__(self):
    self.playlist=sys.modules["__main__"].playlist
def HOME():
        #addDir('Search','http://www.khmeravenue.com/',4,'http://yeuphim.net/images/logo.png')
        if ADDON.getSetting('list_recent_updates') == "true":
            addDir(ADDON.getLocalizedString(30202),'http://'+domain+'/recently-updated/',5,'')
        if ADDON.getSetting('list_hk_dramas') == "true":
            addDir(ADDON.getLocalizedString(30204),'http://'+domain+'/hk-drama/',2,'')
        if ADDON.getSetting('list_hk_movies') == "true":
            addDir(ADDON.getLocalizedString(30205),'http://'+domain+'/hk-movie/',2,'')
        if ADDON.getSetting('list_hk_shows') == "true":
            addDir(ADDON.getLocalizedString(30206),'http://'+domain+'/hk-show/',2,'')
        if ADDON.getSetting('list_korean_dramas') == "true":
            addDir(ADDON.getLocalizedString(30207),'http://'+domain+'/korean-drama/',2,'')
        if ADDON.getSetting('list_mainlan_dramas') == "true":
            addDir(ADDON.getLocalizedString(30208),'http://'+domain+'/chinese-drama/',2,'')
        if ADDON.getSetting('list_taiwanese_dramas') == "true":
            addDir(ADDON.getLocalizedString(30209),'http://'+domain+'/taiwanese-drama/',2,'')
        if ADDON.getSetting('list_korean_shows') == "true":
            addDir(ADDON.getLocalizedString(30210),'http://'+domain+'/korean-show/',2,'')
        if ADDON.getSetting('list_japanese_dramas') == "true":
            addDir(ADDON.getLocalizedString(30211),'http://'+domain+'/japanese-drama/',2,'')
        if ADDON.getSetting('list_movies') == "true":
            addDir(ADDON.getLocalizedString(30212),'http://'+domain+'/movies/',2,'')
        if ADDON.getSetting('list_japanese_anime') == "true":
            addDir(ADDON.getLocalizedString(30213),'http://'+domain+'/japanese-anime/',2,'')
        if ADDON.getSetting('list_us_tv') == "true":
            addDir(ADDON.getLocalizedString(30214),'http://'+domain+'/us-tv-series/',2,'')
 
def INDEX(url): 
    content = GetContent2(url)
    soup = BeautifulSoup(content)
    tiles1 = soup.select('a.movie-image') 
    tiles2 = soup.select('a.poster')
    title_lang_option = ADDON.getSetting('title_language')

    for t in tiles1:
        imageurl = re.search(r'url\((.+?)\)', t['style']).group(1)
        vidurl = urljoin(url, t['href'])
        displayname = t['title']
        names = displayname.split(' - ')

        if title_lang_option == '1':
            displayname = names[0]
        elif title_lang_option == '2':
            displayname = names[-1]

        addDir(displayname, vidurl, MODE_GA_EPISODES, imageurl)

    for t in tiles2:
        imageurl = t.img['src']
        vidurl = t['href']
        displayname = t.img['alt']
        names = displayname.split(' - ')

        if title_lang_option == '1':
            displayname = names[0]
        elif title_lang_option == '2':
            displayname = names[-1]

        addDir(displayname, vidurl, MODE_GA_EPISODES, imageurl)

    pages = soup.select('ul.pager > li > span > a')
    for p in pages:
        pagename = p['title']
        pageurl = urljoin(url, p['href'])
        addDir(pagename, pageurl, MODE_INDEX, '')

def SEARCH():
    try:
        keyb = xbmc.Keyboard('', 'Enter search text')
        keyb.doModal()
        if (keyb.isConfirmed()):
                searchText = urllib.quote_plus(keyb.getText())
        url = 'http://yeuphim.net/movie-list.php?str='+ searchText
        INDEX(url)
    except: pass

#def decodeurl(encodedurl):
#    tempp9 =""
#    tempp4="100108100114971099749574853495756564852485749575656"
#    strlen = len(encodedurl)
#    temp5=int(encodedurl[strlen-4:strlen],10)
#    encodedurl=encodedurl[0:strlen-4]
#    strlen = len(encodedurl)
#    temp6=""
#    temp7=0
#    temp8=0
#    while temp8 < strlen:
#        temp7=temp7+2
#        temp9=encodedurl[temp8:temp8+4]
#        temp9i=int(temp9,16)
#        partlen = ((temp8 / 4) % len(tempp4))
#        partint=int(tempp4[partlen:partlen+1])
#        temp9i=((((temp9i - temp5) - partint) - (temp7 * temp7)) -16)/3
#        temp9=chr(temp9i)
#        temp6=temp6+temp9
#        temp8=temp8+4
#    return temp6

def SearchResults(url):
        link = GetContent(url)
        newlink = ''.join(link.splitlines()).replace('\t','')
        match=re.compile('<aclass="widget-title" href="(.+?)"><imgsrc="(.+?)" alt="(.+?)"').findall(newlink)
        if(len(match) >= 1):
                for vLink,vpic,vLinkName in match:
                    addDir(vLinkName,vLink, MODE_GA_EPISODES,vpic)
        match=re.compile('<strong>&raquo;</strong>').findall(link)
        if(len(match) >= 1):
            startlen=re.compile("<strongclass='on'>(.+?)</strong>").findall(newlink)
            url=url.replace("/page/"+startlen[0]+"/","/page/"+ str(int(startlen[0])+1)+"/")
            addDir("Next >>",url,MODE_SERACH_RESULTS,"")

def Mirrors(url,name):
    try:
        if(CheckRedirect(url)):
                MirrorsThe(name,url)
        else:
                link = GetContent(url)
                newlink = ''.join(link.splitlines()).replace('\t','')
                match=re.compile('<b>Episode list </b>(.+?)</table>').findall(newlink)
                mirrors=re.compile('<div style="margin: 10px 0px 5px 0px">(.+?)</div>').findall(match[0])
                if(len(mirrors) >= 1):
                        for vLinkName in mirrors:
                            if DISPLAY_MIRRORS:
                                addDir(vLinkName,url,MODE_GA_EPISODES,'')
                            else:
                               loadVideos(url, vLinkName.encode("utf-8"))

    except: pass

def Parts(url,name):
        content = GetContent2(url)
        soup = BeautifulSoup(content)

        tites = soup.select('span.tite')
        uldefs = soup.select('ul.tn-uldef')

        zipped = zip(tites, uldefs)

        total = 0
        for t, u in zipped:
            mirror = t.string
            parts = u.find_all('a', recursive=False)

            numparts = len(parts)
            for index, part in enumerate(parts):
                link = part['href']
                name = 'Full' if part.string.strip().lower() == 'full' else ' Part %s/%s' % (index+1, numparts)
                if DISPLAY_MIRRORS:
                    addDir('%s@%s' % (name, mirror), link, MODE_LOAD_VIDEOS, '')
                else:
                    loadVideos(link, '@%s %s' % (mirror, name))
                total += 1

        return total

def CheckParts(url,name):
	if(Parts(url,name) < 2):
		loadVideos(url,name)

def Episodes(url,name,newmode):
    #try:
        link = GetContent2(url)
        try:
            link =link.encode("UTF-8")
        except: pass
        newlink = ''.join(link.splitlines()).replace('\t','')
        if(newmode==MODE_GA_EPISODES):
		# check parts
                vidmode=MODE_CHECKPARTS
        else:
		# Get episode from video
                vidmode=MODE_GET_EPISODES
        soup = BeautifulSoup(newlink)
        match = [(n['href'], n['title']) for n in soup.select('ul.listep > li > a')]

        if match:
	    print newlink
            for (vurl,vname) in match:
                vname = vname.lstrip('Watch ')
                if not url.endswith('/recently-updated/'):
                    vname = vname.split('-')[-1].strip()
                addDir(vname,vurl,vidmode,"")
            pagecontent=re.compile('<div class="wp-pagenavi" align=center>(.+?)</div>').findall(newlink)
            if(len(pagecontent)>0):
                    match5=re.compile('<a href="(.+?)" class="(.+?)" title="(.+?)">(.+?)</a>').findall(pagecontent[0])
                    for vurl,vtmp,vname,vtmp2 in match5:
                        addDir(cleanPage(vname),vurl,newmode,"")
	    # "see more"
	    seemore = soup.find_all('a', text='See more')
	    if (len(seemore)>0) :
		# get episode from video
		addDir("See more", seemore[0]['href'], MODE_GET_EPISODES,"")
        else:
	    btn = soup.select('a.btnWatch') + soup.select('a.full')
            node = btn[0]
            CheckParts(node['href'], node['title'])

    #except: pass

def GetEpisodeFromVideo(url,name):
        link = GetContent(url)
        try:
            link =link.encode("UTF-8")
        except: pass
	#see more
        soup = BeautifulSoup(link)
	listepisode = soup.find_all('a', {'class':'btn-episode'})
	print listepisode
	if (len(listepisode) > 0) :
		for n in listepisode :
			addDir(n['title'], n['href'], MODE_CHECKPARTS, "")
		return
	# old
        newlink = ''.join(link.splitlines()).replace('\t','')
        listcontent=re.compile('<div align="center">(.+?)<div style=[^>]*>').findall(newlink)

	# print listcontent
        if listcontent:
            match=re.compile('<a href="(.+?)"><b>(.+?)</b>').findall(listcontent[0])
            if match:
                for (vurl,vname) in match:
                    addDir("Episode: " + vname,vurl,MODE_CHECKPARTS,"")
            else:
                listcontent=re.compile('<center><a href="(.+?)"><font style="(.+?)">(.+?)</font></a></center>').findall(newlink)
                Episodes(listcontent[0][0]+"list-episode/",name,MODE_GA_EPISODES)
        else:
             listcontent=re.compile('<center><a href="(.+?)"><font style="(.+?)">(.+?)</font></a></center>').findall(newlink)
             Episodes(listcontent[0][0]+"list-episode/",name,MODE_GA_EPISODES)

def GetContent2(url, headers={}):
    try:
       url = url.replace("https", "http")
       response = requests.get(url, headers=headers)
       wrapped_url = response.url
       unwrapped_url = urlparse(wrapped_url).query
       if not unwrapped_url :
	return response.content
       unwrapped_url = unwrapped_url.replace("https", "http")
       unwrapped_response = requests.get(unwrapped_url, headers=headers)
       return unwrapped_response.content
    except:
       d = xbmcgui.Dialog()
       d.ok(url,"Can't Connect to site",'Try again in a moment')

def playVideo(videoType,videoId):
    url = ""
    print "playVideo"
    print videoType + '=' + videoId

    if (videoType == "youtube"):
        url = 'plugin://plugin.video.youtube?path=/root/video&action=play_video&videoid=' + videoId.replace('?','')
        xbmc.executebuiltin("xbmc.PlayMedia("+url+")")
    elif (videoType == "vimeo"):
        url = 'plugin://plugin.video.vimeo/?action=play_video&videoID=' + videoId
    elif (videoType == "tudou"):
        url = 'plugin://plugin.video.tudou/?mode=3&url=' + videoId
    else:
        xbmcPlayer = xbmc.Player()
        xbmcPlayer.play(videoId)

def vidbugresolver1(inputstring,strcat):

	try:
		inputstring=inputstring+strcat
		newstring = urllib.unquote_plus(inputstring[1:len(inputstring)-1])
		t=""
		for i in range(len(newstring)):
			t=t+chr(ord(newstring[i])-int(inputstring[0:1]))
	except:
		t=vidbugresolver2(inputstring)
	return t

def vidbugresolver2(inputstring):
	newstring = urllib.unquote_plus(inputstring[:-1])
	t=""
	for i in range(len(newstring)):
		t=t+chr(ord(newstring[i])-int(inputstring[-1:]))
	return t

def vidbugresolver(inputstringorig):
	attempts=0
	inputstring=""
	t=""
	result=None
	while attempts < 10:
		#if True:
		print "attempts =" + str(attempts)
		try:
			if(attempts!=0):
				t=vidbugresolver1(inputstringorig,str(attempts))
			else:
				t=vidbugresolver1(inputstringorig,"")
			result= re.compile('json_allupload\d?.php",{vidID:\s*"(.+?)",vidKey:\s*"(.+?)",').findall(t)[0]
			break
		except:
			attempts += 1

	return result


def getDailyMotionUrls(id):
    content = GetContent("http://www.dailymotion.com/embed/video/"+id)
    if content.find('"statusCode":410') > 0 or content.find('"statusCode":403') > 0:
        xbmc.executebuiltin('XBMC.Notification(Info:,'+translation(30022)+' (DailyMotion)!,5000)')
        return ""

    else:
        get_json_code = re.compile(r'dmp\.create\(document\.getElementById\(\'player\'\),\s*(.+?)}}\)').findall(content)[0]
        #print len(get_json_code)
        print get_json_code
        cc= json.loads(get_json_code+"}}")['metadata']['qualities']  #['380'][0]['url']
        #print cc
        keys = cc.keys()
        possible_keys = ['1080', '720', '480', '380', '240', 'auto']
        urls = [(cc[q][0]['url'], q.capitalize()) for q in possible_keys if q in keys]
        if not urls:
            xbmc.executebuiltin('XBMC.Notification(Info:, No playable Link found (DailyMotion)!,5000)')

def getH265Url(url):
	content = GetContent(url)
        if jsunpack.detect(content):
        	content = jsunpack.unpack(content)
 	a = re.findall(r'file:"(.*?)"', content)
	return a[-1] if a else url

def getUptostream(url):
	content = GetContent(url)
	soup = BeautifulSoup(content)
	a = soup.find_all('source', {'type':'video/mp4'})
	return "http:"+a[-1]['src'] if a else url 

def resolveUrl(url):
	if (url.find("h265") > -1):
		return getH265Url(url)
	elif (url.find("uptostream") > -1):
		return getUptostream(url)
	else :	
		return url

def get_post_data(html):
        results = re.findall(r'<script.+src="(.+\.vbjs\.html)".+decodeURIComponent\("(.+?)"\).+?R\[.+?\]\}\}\(''(.+?)''\).+(<\/script>|\/>)', html)

        if results:
            try:
                key = results[0][2]
                key = key.replace("'", "")
                encrypted_string = urllib.unquote(results[0][1])
                decoded_result = ''

                for c in range(0, len(encrypted_string)):
                    code = ord(encrypted_string[c]) ^ ord(key[c % len(key)])
                    character = chr(code)
                    decoded_result = decoded_result + character

                data = decoded_result.split('~|.')
                return  {
                    'VB_ID': data[1],
                    'VB_TOKEN': data[0],
                    'VB_NAME': ''
                }
            except Exception as e:
                import xbmc
                xbmc.log(str(e), xbmc.LOGERROR)

        return None

def get_vb_data(html):
               results = re.findall(r'\.vbjs\.html"><\/script><script>(.+)<\/script>', html)
	       if not results : return None
 	       context = js2py.EvalJs()
	       context.execute("""
               escape = function(text){pyimport urllib; return urllib.quote(text)};
	       unescape = function(text){pyimport urllib; return urllib.unquote(text)};
	       encodeURI = function(text){pyimport urllib; return urllib.quote(text, safe='~@#$&()*!+=:;,.?/\\'')};
	       decodeURI = unescape;
	       encodeURIComponent = function(text){pyimport urllib; return urllib.quote(text, safe='~()*!.\\'')};
	       decodeURIComponent = unescape;
 	       window = 0;
	       global = 0;
	       """)
	       context.execute(results[0])
	       js_vbtoken = context.VB_TOKEN	        
               js_vbid = context.VB_ID	        
	       data = {'VB_ID': js_vbid, 'VB_TOKEN': js_vbtoken, 'VB_NAME': ''}
	       return data

def get_vlist_data(html, headers):
	       # get vbjs 
               results = re.findall(r'<script.+src="(.+\.vbjs\.html)".+(<\/script>|\/>)', html)
	       if not results : return None
	       link = "http://videobug.se"+results[0][0]
 	       # get vbjs script
	       vb_content = GetContent2(link, headers)
	       if not vb_content : return None
               vbid = ''
               vbtoken = ''
               vbname = ''
               for var in vb_content.split(';'):
                    if 'VB_ID' in var:
                        vbid = re.findall(r'\"(.+?)\"', var)[0]
                    if 'VB_TOKEN' in var:
                        vbtoken = re.findall(r'\"(.+?)\"', var)[0]
                    if 'VB_NAME' in var:
                        vbname = re.findall(r'\"(.+?)\"', var)[0]
		
               data = { 'VB_ID': vbid, 'VB_TOKEN': vbtoken, 'VB_NAME': vbname }
	       return data

def get_php_data(html):
                #results = re.findall(r'"\/vbjs\.php"><\/script>.+<script>(.+)<\/script>', html)
                #results = re.findall(r'vbjs.php"><\/script>.+\n.+<script>(.+)<\/script>', html)
                results = re.findall(r'vbjs.php.+"><\/script>.+\n.+<script>(.+)<\/script>', html)
		print results 
		if not results : return None
		context = js2py.EvalJs()
	        context.execute(results[0])
		data = { 'VB_ID' : context.VB_ID, 'VB_TOKEN': context.VB_TOKEN, 'VB_NAME': ''}
		return data

def Videosresolve(url,name,referer):
        #try:
           newlink=url
           print "Videosresolve | " + url + " | " + referer 

           if (newlink.find("videobug") > -1) or (newlink.find("vlist") > -1):
	       headers = { 'User-Agent':UASTR, 'Referer':referer }
	       html = GetContent2(newlink, headers)
               # print html
               vidlink = []
	       data = None

	       #data = get_vlist_data(html, headers)
	       #print data
               #data = get_post_data(html)
               #print data 
	       if not data : data = get_php_data(html)
               if not data : data = get_vb_data(html)
	       # if not data : data = get_vlist_data(html, headers)
	       # print data
	       
	       #url = "https://vb.h265.se/v/p"
	       url = "http://vb.icdrama.se/v/p"
       	       headers['Referer'] = 'http://vb.icdrama.se/v/'+data['VB_ID']+'.html'

	       print headers
	       resp = requests.post(url, data=data, headers=headers)
               json_data = resp.content[3:]

               # Allupload
               # http://videobug.se/vid-a/g2S5k34-MoC2293iUaa9Hw
               # json_data = re.findall(r"json_data = '(.+)';", content)
               if json_data:
                   # strdecode = lambda s: base64.b64decode(urllib.unquote(s)[::-1])		
                   forward = lambda s: base64.b64decode(urllib.unquote(s))
                   backward = lambda s: base64.b64decode(urllib.unquote(s)[::-1])
                   strdecode = lambda s: forward(s) if (forward(s) != TypeError) else backward(s)
                   try:
                       # hashes = json.loads(json_data[0])
                       hashes = json.loads(json_data)
                       exclude = ['Subtitles', 'image', 'JS', 'ADV']
                       videos = [h for h in hashes if h['s'] not in exclude]
                       vidlink = [(resolveUrl(strdecode(h['u'])), h['s']) for h in videos]
                   except Exception:
                       pass

               # Picasaweb, Videobug
               # http://videobug.se/video/Wz3_oCoEYozRSbJFQo4fkjmuvR6LpsFHM-XZya5tuk6stTXWdUeyplq5vVvSm0Yr0MXPFUmLt2XqrbLMPnE_Mgz8NbhXMZ6XFDI4hj253Z7af95WQPPDlpizIuuUXavEJqB8-bXuKbx6HTCMb5p5FC90yg1kXJb6?
               if not vidlink:
                   soup = BeautifulSoup(content)
                   player_func = re.compile(r'(player_[^\(]+)\(\);').match
                   butts = soup.find_all('input', type='button', onclick=player_func)

                   funcs = [player_func(b['onclick']).group(1) for b in butts]
                   qualities = [b['value'] for b in butts]

                   try:
                       func_bodies = [re.findall(r'%s\(\) *{(.+)};' % f, content)[0] for f in funcs]
                       re_flash = re.compile(r"video *= *{[^:]+: *'(.*?)' *}")
                       re_html5 = re.compile(r'<source.*?src=\"(.*?)\"')

                       urls = [(re_flash.findall(fb) or re_html5.findall(fb))[0] for fb in func_bodies]
                       vidlink = zip(urls, qualities)
                   except Exception:
                       pass

               # http://videobug.se/vid-al/XNkjCT5pBx1YlndruYWdWg?&caption=-sgCv7BkuLZn41-ZxxJZhTsKYcZIDgJPGYNOuIpulC_4kcrZ9k3fGQabH5rDAKgiLMVJdesVZPs
               if not vidlink:
                   vids = re.findall(r'''{ *file *: *strdecode\('(.+?)'\).*?label *: *"(.*?)"''', content)
                   for cryptic_url, quality in vids:
                       url = base64.b64decode(urllib.unquote(cryptic_url)[::-1])
                       vidlink.append((url, quality))

           else:
                import urlresolver
                sources = []
                label=name
                hosted_media = urlresolver.HostedMediaFile(url=url, title=label)
                sources.append(hosted_media)
                source = urlresolver.choose_source(sources)
                if source:
                        vidlink = [(source.resolve(), 'Unknown Quality')]
                else:
                        vidlink = []
	   
	   print vidlink

           return vidlink

def loadVideos(url,name):
		GA("LoadVideo",name)
		episode_name = ""
		print "loading from video " + url
		if DISPLAY_MIRRORS == False:
			episode_name = name
		link=GetContent2(url)
		newlink = ''.join(link.splitlines()).replace('\t','')
		try:
			newlink =newlink.encode("UTF-8")
		except: pass

                soup = BeautifulSoup(newlink)
                match = [m['src'] for m in soup.select('iframe')]

                if match:
                    frameurl = match[0]
                else:
                    frameurl = decodeurl(re.compile('dl.link=dll\*(.+?)&').findall(newlink)[0])

		#detect base64 encode link inside iframe url
		m = re.search("iframe.html#(.*)", frameurl)
		if m:
		    frameurl = base64.b64decode(m.group(1))
	
                videos = Videosresolve(frameurl, name, url)
                for url, quality in videos:
                    pre = episode_name + ': ' if episode_name else ''
                    addLink(pre + quality, url, 8, '', '')


def parseDate(dateString):
    try:
        return datetime.datetime.fromtimestamp(time.mktime(time.strptime(dateString.encode('utf-8', 'replace'), "%Y-%m-%d %H:%M:%S")))
    except:
        return datetime.datetime.today() - datetime.timedelta(days = 1) #force update


def checkGA():
    if GA_PRIVACY == True:
        return
    secsInHour = 60 * 60
    threshold  = 2 * secsInHour

    now   = datetime.datetime.today()
    prev  = parseDate(ADDON.getSetting('ga_time'))
    delta = now - prev
    nDays = delta.days
    nSecs = delta.seconds

    doUpdate = (nDays > 0) or (nSecs > threshold)
    if not doUpdate:
        return

    ADDON.setSetting('ga_time', str(now).split('.')[0])
    APP_LAUNCH()


def send_request_to_google_analytics(utm_url):
    if GA_PRIVACY == True:
        return
    import urllib2
    try:
        req = urllib2.Request(utm_url, None,
                                    {'User-Agent':UASTR}
                                     )
        response = urllib2.urlopen(req).read()
    except:
        print ("GA fail: %s" % utm_url)
    return response

def GA(group,name):
        if GA_PRIVACY == True:
            return
        try:
            try:
                from hashlib import md5
            except:
                from md5 import md5
            from random import randint
            import time
            from urllib import unquote, quote
            from os import environ
            from hashlib import sha1
            VISITOR = ADDON.getSetting('ga_visitor')
            utm_gif_location = "http://www.google-analytics.com/__utm.gif"
            if not group=="None":
                    utm_track = utm_gif_location + "?" + \
                            "utmwv=" + VERSION + \
                            "&utmn=" + str(randint(0, 0x7fffffff)) + \
                            "&utmt=" + "event" + \
                            "&utme="+ quote("5("+PATH+"*"+group+"*"+name+")")+\
                            "&utmp=" + quote(PATH) + \
                            "&utmac=" + UATRACK + \
                            "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR,VISITOR,"2"])
                    try:
                        print "============================ POSTING TRACK EVENT ============================"
                        send_request_to_google_analytics(utm_track)
                    except:
                        print "============================  CANNOT POST TRACK EVENT ============================"
            if name=="None":
                    utm_url = utm_gif_location + "?" + \
                            "utmwv=" + VERSION + \
                            "&utmn=" + str(randint(0, 0x7fffffff)) + \
                            "&utmp=" + quote(PATH) + \
                            "&utmac=" + UATRACK + \
                            "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])
            else:
                if group=="None":
                       utm_url = utm_gif_location + "?" + \
                                "utmwv=" + VERSION + \
                                "&utmn=" + str(randint(0, 0x7fffffff)) + \
                                "&utmp=" + quote(PATH+"/"+name) + \
                                "&utmac=" + UATRACK + \
                                "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])
                else:
                       utm_url = utm_gif_location + "?" + \
                                "utmwv=" + VERSION + \
                                "&utmn=" + str(randint(0, 0x7fffffff)) + \
                                "&utmp=" + quote(PATH+"/"+group+"/"+name) + \
                                "&utmac=" + UATRACK + \
                                "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR, VISITOR,"2"])

            print "============================ POSTING ANALYTICS ============================"
            send_request_to_google_analytics(utm_url)

        except:
            print "================  CANNOT POST TO ANALYTICS  ================"


def APP_LAUNCH():
        versionNumber = int(xbmc.getInfoLabel("System.BuildVersion" )[0:2])
        if versionNumber > 13:
			logname="kodi.log"
        else:
			logname="xbmc.log"
        if versionNumber < 12:
            if xbmc.getCondVisibility('system.platform.osx'):
                if xbmc.getCondVisibility('system.platform.atv2'):
                    log_path = '/var/mobile/Library/Preferences'
                else:
                    log_path = os.path.join(os.path.expanduser('~'), 'Library/Logs')
            elif xbmc.getCondVisibility('system.platform.ios'):
                log_path = '/var/mobile/Library/Preferences'
            elif xbmc.getCondVisibility('system.platform.windows'):
                log_path = xbmc.translatePath('special://home')
                log = os.path.join(log_path, logname)
                logfile = open(log, 'r').read()
            elif xbmc.getCondVisibility('system.platform.linux'):
                log_path = xbmc.translatePath('special://home/temp')
            else:
                log_path = xbmc.translatePath('special://logpath')
            log = os.path.join(log_path, logname)
            logfile = open(log, 'r').read()
            match=re.compile('Starting XBMC \((.+?) Git:.+?Platform: (.+?)\. Built.+?').findall(logfile)
        elif versionNumber > 11:
            print '======================= more than ===================='
            log_path = xbmc.translatePath('special://logpath')
            log = os.path.join(log_path, logname)
            logfile = open(log, 'r').read()
            match=re.compile('Starting XBMC \((.+?) Git:.+?Platform: (.+?)\. Built.+?').findall(logfile)
        else:
            logfile='Starting XBMC (Unknown Git:.+?Platform: Unknown. Built.+?'
            match=re.compile('Starting XBMC \((.+?) Git:.+?Platform: (.+?)\. Built.+?').findall(logfile)
        print '==========================   '+PATH+' '+VERSION+'  =========================='
        try:
            from hashlib import md5
        except:
            from md5 import md5
        from random import randint
        import time
        from urllib import unquote, quote
        from os import environ
        from hashlib import sha1
        import platform
        VISITOR = ADDON.getSetting('ga_visitor')
        for build, PLATFORM in match:
            if re.search('12',build[0:2],re.IGNORECASE):
                build="Frodo"
            if re.search('11',build[0:2],re.IGNORECASE):
                build="Eden"
            if re.search('13',build[0:2],re.IGNORECASE):
                build="Gotham"
            print build
            print PLATFORM
            utm_gif_location = "http://www.google-analytics.com/__utm.gif"
            utm_track = utm_gif_location + "?" + \
                    "utmwv=" + VERSION + \
                    "&utmn=" + str(randint(0, 0x7fffffff)) + \
                    "&utmt=" + "event" + \
                    "&utme="+ quote("5(APP LAUNCH*"+build+"*"+PLATFORM+")")+\
                    "&utmp=" + quote(PATH) + \
                    "&utmac=" + UATRACK + \
                    "&utmcc=__utma=%s" % ".".join(["1", VISITOR, VISITOR, VISITOR,VISITOR,"2"])
            try:
                print "============================ POSTING APP LAUNCH TRACK EVENT ============================"
                send_request_to_google_analytics(utm_track)
            except:
                print "============================  CANNOT POST APP LAUNCH TRACK EVENT ============================"

checkGA()

def addLink(name,url,mode,iconimage,mirrorname):
        name = cleanName(name)
        u=sys.argv[0]+"?url="+urllib.quote_plus(url.encode('utf-8'))+"&mode="+str(mode)+"&name="+urllib.quote_plus(name.encode('utf-8'))+"&mirrorname="+urllib.quote_plus(mirrorname)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        contextMenuItems = []
        liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok

def addNext(formvar,url,mode,iconimage):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&formvar="+str(formvar)+"&name="+urllib.quote_plus('Next >')
        ok=True
        liz=xbmcgui.ListItem('Next >', iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": 'Next >' } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addDir(name,url,mode,iconimage):
        try:
            name = name.encode('utf-8')
        except:
            pass
        try:
            url = url.encode('utf-8')
        except:
            pass
        name = cleanName(name)
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def cleanName(name):
        strireplace = re.compile(re.escape('Watch Online '), re.IGNORECASE)
        return strireplace.sub('',name)

def cleanPage(name):
        strireplace = re.compile(re.escape('&raquo;'), re.IGNORECASE)
        name = strireplace.sub('Last',name)
        strireplace = re.compile(re.escape('&laquo; First'), re.IGNORECASE)
        name = strireplace.sub('First Page',name)
        return name

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]

        return param



params	=	get_params()
url	=	None
name	=	None
mode	=	None
formvar	=	None
mirrorname=	None
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        mirrorname=urllib.unquote_plus(params["mirrorname"])
except:
        pass

sysarg=str(sys.argv[1])
print "mode is:" + str(mode)
if mode==None or url==None or len(url)<1:

        HOME()
elif mode==MODE_INDEX :
        GA("INDEX",name)
        INDEX(url)
elif mode==MODE_LOAD_VIDEOS :
        loadVideos(url,mirrorname)
elif mode==MODE_SEARCH:
        SEARCH()
elif mode==MODE_GA_EPISODES:
       GA("Episodes",name)
       Episodes(url,name,mode)
elif mode==MODE_SERACH_RESULTS:
       SearchResults(url)
elif mode==MODE_EPISODES:
       Episodes(url,name,mode)
elif mode==MODE_PLAY:
        playVideo("direct",url)
elif mode==MODE_GET_EPISODES:
       GetEpisodeFromVideo(url,name)
elif mode==MODE_EPISODES2:
       Episodes2(url,name)
elif mode==MODE_CHECKPARTS:
       CheckParts(url,name)

xbmcplugin.endOfDirectory(int(sysarg))
