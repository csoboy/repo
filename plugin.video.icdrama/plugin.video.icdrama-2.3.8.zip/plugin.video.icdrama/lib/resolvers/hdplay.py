import re

import json
from urllib.parse import unquote
from urllib.parse import urlparse
import base64
import requests
from bs4 import BeautifulSoup
import resolveurl
from resolveurl import common
from resolveurl.resolver import ResolveUrl, ResolverError
from resolveurl.lib import helpers
import xbmc
from .. import common as cmn

class HdPlay(ResolveUrl):
    name = 'HDplay'
    domains = [ 'hdplay.se', 'adramas.se', 'adramas.site']
    # pattern = '(?://|\.)(hdplay\.se)/(.+)'
    # pattern = '(?://|\.)(hdplay\.se|drive.adramas\.se)/(.+)'
    pattern = '(?://|\.)(www2\.adramas\.site)/(.+)'

    def __init__(self):
        self.net = common.Net()
        self.headers = {'User-Agent': common.RAND_UA, 'Referer':'https://drive.adramas.se/'}
  
    def get_media_url(self, host, media_id):

        eps_id = media_id.rsplit("/", 1)[-1]
        if "html" in eps_id :
            # remove html
            no_extension = eps_id.split(".")[0]
            # split last "-"
            eId = no_extension.rsplit("-")[-1]
        else :
            eps_json = requests.get("https://www2.adramas.site/api/episodes/{}".format(eps_id)).content.decode("utf-8")
            eps_dict = json.loads(eps_json)

            eId = eps_dict["episode"]["servers"][0]["eId"]

        vd_json = requests.get("https://www2.adramas.site/api/ep/{}".format(eId)).content.decode("utf-8")
        vd_links = json.loads(vd_json)

        for vd in vd_links :
            vd_link = vd["videourl"]
            if 'm3u8' in vd_link :
                return vd_link

        if 'm3u8' in media_id :
            return url + helpers.append_headers(self.headers)
       
        response = requests.get(url, headers=self.headers)

        if response.status_code == 200:
            html = response.content.decode("utf-8")
            # capture everything, regardless of single or double quotes
            # match = re.search(r'var\s+video_url\s*=\s*"([^\\"]+)"', html)
            # match = re.search(r'<div id=video_url style=display:none>(.+?)<\/div>', html)
            match = re.search(r'streamUrl="(.+?)"', html)
            if match:
                video_url = 'http://' + host + match.group(1)
                #video_url = video_url.split('m3u8')[0]+'m3u8'
                return video_url + helpers.append_headers(self.headers)
            xbmc.log("html: %s" % html, xbmc.LOGERROR)


        raise ResolverError("Unable to resolve url in hdplay: %s" % response)

    def get_url(self, host, media_id):
        return self._default_get_url(host, media_id, 'https://%s/%s' % (host, media_id))

    @classmethod
    def _is_enabled(cls):
        return True
